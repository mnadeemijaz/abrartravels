<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Muhammad Nadeem Ijaz
 * @version : 1.1
 * @since : 14 august 2018
 */
class Reports extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
		/*$config = $this->config_model->getConfig();
        $this->global['pageTitle'] = $config->name.' : Dashboard';
		
        $data['total_clients'] = $data1= $this->hotel_other_model->total_clients();
		$data['pilgrims'] = $this->hotel_other_model->pilgrims();
		$data['total_vouchers'] = $data1= $this->hotel_other_model->total_vouchers();
		$data['approved_vouchers'] = $data1= $this->hotel_other_model->approved_vouchers();
		$data['not_approved'] = $data1= $this->hotel_other_model->not_approved();
		
        $this->loadViews("dashboard", $this->global, $data , NULL);*/
    }
	public function pilgrim_report($row_no=0)
	{
		check_permission(11);
		$searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText; 
		$age_group = ($this->input->post('age_group'))?$this->input->post('age_group'):'';
		$config = $this->config_model->getConfig();
		$search_data['agent_id'] =$agent_id= ($this->input->post('agent_id'))?$this->input->post('agent_id'):'';
		$search_data['row_no'] = $row_no;
		$data['count'] = $row_no;
			if($this->input->post()){
				$this->session->set_userdata('sedata',$search_data);
			}else{
				if($this->session->userdata('sedata') != null){
					$search_data = $this->session->userdata('sedata');
				}
			}
		$count = $this->report_model->pilgrim_count($agent_id,$age_group,$searchText,$search_data);
		/////// PAGINATAION 
			$config1 ['base_url'] = base_url () . "pilgrim_report/";
			$config1 ['total_rows'] = $count;
			$config1 ['per_page'] = $config->per_page;		
			$this->pagination->initialize ( $config1 );
		/////// END PAGINATION 
		//$returns = $this->paginationCompress ( "pilgrim_report/", $count, $config->per_page);            
		$data['pilgrim_report'] = $this->report_model->pilgrim_report($config->per_page, $row_no,$agent_id,$age_group,$searchText,$search_data);
		$data['agent'] = $this->hotel_other_model->agent_list_users();
		$this->global['pageTitle'] = $config->name.' : Hotel Listing';            
        $this->loadViews("reports/pilgrim_report", $this->global, $data, NULL);
	}
	public function arrival_report($row_no = 0)
	{
		check_permission(11);
		$config = $this->config_model->getConfig();
		$data['count'] = $row_no;
		$search_data['company_id'] =$company_id= ($this->input->post('company_id'))?$this->input->post('company_id'):'';
		$search_data['city'] =$city= ($this->input->post('city'))?$this->input->post('city'):'';
		$search_data['date_range'] = $datefilter= ($this->input->post('date_range'))?$this->input->post('date_range'):'';
		if($datefilter){
			$date = explode(' - ',$datefilter);
			$search_data['start_date'] = $start_date = $date[0];
			$search_data['end_date'] = $end_date = $date[1];
		}
		else{
			$search_data['start_date'] = $start_date = '';
			$search_data['end_date'] = $end_date = '';
		}
		if($this->input->post()){
				$this->session->set_userdata('sdata',$search_data);
			}else{
				if($this->session->userdata('sdata') != null){
					$search_data = $this->session->userdata('sdata');
				}
			}
		$count = $this->report_model->arrival_count($city,$company_id,$start_date,$end_date,$search_data);
		/////// PAGINATAION 
			$config1 ['base_url'] = base_url () . "arrival_report/";
			$config1 ['total_rows'] = $count;
			$config1 ['per_page'] = $config->per_page;		
			$this->pagination->initialize ( $config1 );
		/////// END PAGINATION
		//$returns = $this->paginationCompress ( "pilgrim_report/", $count, $config->per_page);            
		$data['arrival_report'] = $this->report_model->arrival_report($config->per_page, $row_no,$city,$company_id,$start_date,$end_date,$search_data);
		$data['visaCompany'] = $this->hotel_other_model->visaCompany_list();
		$this->global['pageTitle'] = $config->name.' : Arrival Report';            
        $this->loadViews("reports/arrival_report", $this->global, $data, NULL);
	}
	public function departure_report($row_no = 0)
	{
		check_permission(11);
		$config = $this->config_model->getConfig();
		$data['count'] = $row_no;
		$search_data['company_id'] =$company_id= ($this->input->post('company_id'))?$this->input->post('company_id'):'';
		$search_data['city'] =$city= ($this->input->post('city'))?$this->input->post('city'):'';
		$search_data['date_range'] = $datefilter= ($this->input->post('date_range'))?$this->input->post('date_range'):'';
		if($datefilter){
			$date = explode(' - ',$datefilter);
			$data['start_date'] = $start_date = $date[0];
			$data['end_date'] = $end_date = $date[1];
		}
		else{
			$data['start_date'] = $start_date = '';
			$data['end_date'] = $end_date = '';
		}
		if($this->input->post()){
				$this->session->set_userdata('ddata',$search_data);
			}else{
				if($this->session->userdata('ddata') != null){
					$search_data = $this->session->userdata('ddata');
				}
			}
		$count = $this->report_model->departure_count($city,$company_id,$start_date,$end_date,$search_data);
		//$returns = $this->paginationCompress ( "pilgrim_report/", $count, $config->per_page); 
		/////// PAGINATAION 
			$config1 ['base_url'] = base_url () . "departure_report/";
			$config1 ['total_rows'] = $count;
			$config1 ['per_page'] = $config->per_page;		
			$this->pagination->initialize ( $config1 );
		/////// END PAGINATION            
		$data['arrival_report'] = $this->report_model->departure_report($config->per_page, $row_no,$city,$company_id,$start_date,$end_date,$search_data);
		$data['visaCompany'] = $this->hotel_other_model->visaCompany_list();
		$this->global['pageTitle'] = $config->name.' : Departure Report';            
        $this->loadViews("reports/departure_report", $this->global, $data, NULL);
	}
	public function visa_report($row_no)
	{
		check_permission(11);
		$searchText = $this->input->post('searchText');
            $search_data['searchText'] = $searchText; 
		$config = $this->config_model->getConfig();
		$data['counter'] = $row_no;
		$search_data['company_id'] =$company_id= ($this->input->post('company_id'))?$this->input->post('company_id'):'';
		$search_data['status'] = $status = ($this->input->post('status'))?$this->input->post('status'):'';
		if($this->input->post()){
				$this->session->set_userdata('vdata',$search_data);
			}else{
				if($this->session->userdata('vdata') != null){
					$search_data = $this->session->userdata('vdata');
				}
			}
		$count = $this->report_model->visa_count($company_id,$status,$searchText,$search_data);
		//$returns = $this->paginationCompress ( "pilgrim_report/", $count, $config->per_page);            
		/////// PAGINATAION 
			$config1 ['base_url'] = base_url () . "visa_report/";
			$config1 ['total_rows'] = $count;
			$config1 ['per_page'] = $config->per_page;		
			$this->pagination->initialize ( $config1 );
		/////// END PAGINATION 
		$data['visa_report'] = $this->report_model->visa_report($config->per_page, $row_no,$company_id,$status,$searchText,$search_data);
		$data['visaCompany'] = $this->hotel_other_model->visaCompany_list();
		$this->global['pageTitle'] = $config->name.' : Visa Report';            
        $this->loadViews("reports/visa_report", $this->global, $data, NULL);
	}
	public function pilgrim_wise_report($row_no = 0)
	{
		//echo $row_no;die();
		//check_permission(11);
		$searchText = $this->input->post('searchText');
            $search_data['searchText'] = $searchText; 
		$config = $this->config_model->getConfig();
		$data['count'] = $row_no;
		$search_data['agent_id'] =$agent_id= ($this->input->post('agent_id'))?$this->input->post('agent_id'):'';
		if($this->input->post()){
				$this->session->set_userdata('pdata',$search_data);
			}else{
				if($this->session->userdata('pdata') != null){
					$search_data = $this->session->userdata('pdata');
				}
			}
		$count = $this->report_model->pilgrim_wise_count($agent_id,$searchText,$search_data);
		//echo $config->per_page;die();
		//$returns = $this->paginationCompress ( "pilgrim_wise_report/", $count, $config->per_page);            
		/////// PAGINATAION 
			$config1 ['base_url'] = base_url () . "pilgrim_wise_report/";
			$config1 ['total_rows'] = $count;
			$config1 ['per_page'] = $config->per_page;		
			$this->pagination->initialize ( $config1 );
		/////// END PAGINATION 
		$data['pilgrim_wise_report'] = $this->report_model->pilgrim_wise_report($row_no,$config->per_page,$agent_id,$searchText,$search_data);
		$data['agent'] = $this->hotel_other_model->agent_list_users();
		$this->global['pageTitle'] = $config->name.' : Pilgrim Wise Report';            
        $this->loadViews("reports/pilgrim_wise_report", $this->global, $data, NULL);
	}
    	
	
	////////// end Reports /////////////
	public function arrival_report_excel($row_no)
	{
		$search_data = $this->session->userdata('seardata');
		$config = $this->config_model->getConfig(); 
		$data['arrival_report'] = $this->report_model->arrival_report($config->per_page, $row_no,$city,$company_id,$start_date,$end_date,$search_data);
		$this->global['pageTitle'] = $config->name.' : Arrival Report';            
        $this->load->view("reports/arrival_report_excel", $data);
	}
	public function arrival_report_word($row_no)
	{
		$search_data = $this->session->userdata('seardata');
		$config = $this->config_model->getConfig(); 
		$data['arrival_report'] = $this->report_model->arrival_report($config->per_page, $row_no,$city,$company_id,$start_date,$end_date,$search_data);
		$this->global['pageTitle'] = $config->name.' : Arrival Report';            
        $this->load->view("reports/arrival_report_word", $data);
	}
	public function pilgrim_report_word($row_no)
	{        
		$search_data = $this->session->userdata('sedata');
		$config = $this->config_model->getConfig();   
		$data['pilgrim_report'] = $this->report_model->pilgrim_report($config->per_page, $row_no,$agent_id,$age_group,$searchText,$search_data);		      
        $this->load->view("reports/pilgrim_report_word", $data);
	}
	public function pilgrim_report_excel($row_no)
	{
		$search_data = $this->session->userdata('sedata');
		$config = $this->config_model->getConfig();
		$data['pilgrim_report'] = $this->report_model->pilgrim_report($config->per_page, $row_no,$agent_id,$age_group,$searchText,$search_data);		      
        $this->load->view("reports/pilgrim_report_excel", $data);
	}
	public function departure_report_excel($row_no)
	{
		$search_data = $this->session->userdata('ddata');
		$config = $this->config_model->getConfig(); 
		$data['arrival_report'] = $this->report_model->departure_report($config->per_page, $row_no,$city,$company_id,$start_date,$end_date,$search_data);
		$data['visaCompany'] = $this->hotel_other_model->visaCompany_list();
        $this->load->view("reports/departure_report_excel", $data);
	}
	public function departure_report_word($row_no)
	{
		$search_data = $this->session->userdata('ddata');
		$config = $this->config_model->getConfig(); 
		$data['arrival_report'] = $this->report_model->departure_report($config->per_page, $row_no,$city,$company_id,$start_date,$end_date,$search_data);
		$data['visaCompany'] = $this->hotel_other_model->visaCompany_list();
        $this->load->view("reports/departure_report_word", $data);
	}
	public function visa_report_excel($row_no)
	{
		$search_data = $this->session->userdata('vdata');
		$config = $this->config_model->getConfig();          
		$data['visa_report'] = $this->report_model->visa_report($config->per_page, $row_no,$company_id,$status,$searchText,$search_data);
		$data['visaCompany'] = $this->hotel_other_model->visaCompany_list();
        $this->load->view("reports/visa_report_excel",$data);
	}
	public function visa_report_word($row_no)
	{
		$search_data = $this->session->userdata('vdata');
		$config = $this->config_model->getConfig(); 
		$data['visa_report'] = $this->report_model->visa_report($config->per_page, $row_no,$company_id,$status,$searchText,$search_data);
		$data['visaCompany'] = $this->hotel_other_model->visaCompany_list();
        $this->load->view("reports/visa_report_word",$data);
	}
	public function pilgrim_wise_word($row_no)
	{
		$search_data = $this->session->userdata('pdata');
		$config = $this->config_model->getConfig(); 
		$data['pilgrim_wise_report'] = $this->report_model->pilgrim_wise_report($row_no,$config->per_page,$agent_id,$searchText,$search_data);		      
        $this->load->view("reports/pilgrim_wise_word", $data);
	}
	public function pilgrim_wise_excel($row_no)
	{
		$search_data = $this->session->userdata('pdata');
		$config = $this->config_model->getConfig(); 
		$data['pilgrim_wise_report'] = $this->report_model->pilgrim_wise_report($row_no,$config->per_page,$agent_id,$searchText,$search_data);		      
        $this->load->view("reports/pilgrim_wise_excel", $data);
	}


    function pageNotFound()
    {
        $this->global['pageTitle'] = ' 404 - Page Not Found';
        
        $this->loadViews("404", $this->global, NULL, NULL);
    }
}

?>