<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : client (ClientController)
 * User Class to control all user related operations.
 * @author : Muhammad Nadeem Ijaz
 * @version : 1.1
 * @Phone : 923467547186, 923017893497
 */
class Client extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index($row_no = 0)
    {
		check_permission(4);
        /*if($this->isAdminUser() == TRUE)
        {
            $this->loadThis();
        }
        else
        {*/   
			$data['count'] = $row_no;     
            $searchText = $this->input->post('searchText');
            $search_data['searchText'] = $searchText; 
			$search_data['age_group'] = $age_group = ($this->input->post('age_group'))?$this->input->post('age_group'):'';
			$search_data['visa_approve'] = $visa_approve = ($this->input->post('visa_approve'))?$this->input->post('visa_approve'):'';
			$search_data['agentRecords'] = $this->hotel_other_model->agent_list_users();
			$search_data['agent_id'] = $agent_id = ($this->input->post('agent_id'))?$this->input->post('agent_id'):'';
			$search_data['documentation'] = $documentation = ($this->input->post('documentation'))?$this->input->post('documentation'):
			$search_data['voucher_issue'] = 'no';
			$search_data['row_no'] = $row_no;
			if($this->input->post()){
				$this->session->set_userdata('seardata',$search_data);
			}else{
				if($this->session->userdata('seardata') != null){
					$search_data = $this->session->userdata('seardata');
				}
			}
			$config = $this->config_model->getConfig();
			$voucher_issue = 'no';
            $count = $this->client_model->client_count($searchText,$age_group,$visa_approve,$agent_id,$voucher_issue,$search_data);
			/////// PAGINATAION 
				$config1 ['base_url'] = base_url () . "client/";
				$config1 ['total_rows'] = $count;
				$config1 ['per_page'] = $config->per_page;		
				$this->pagination->initialize ( $config1 );
			/////// END PAGINATION 
			$data['clientRecords'] = $this->client_model->client_list($searchText, $config->per_page, $row_no,$age_group,$visa_approve,$agent_id,$voucher_issue,$search_data);
			//print_r($data['clientRecords']);
			//$returns = $this->paginationCompress ( "client/", $count, $config->per_page);            
            //$data['clientRecords'] = $this->client_model->client_list($searchText, $returns["page"], $returns["segment"],$age_group,$visa_approve,$agent_id,$voucher_issue);
			$data['agentRecords'] = $this->hotel_other_model->agent_list_users();
            $this->global['pageTitle'] = $config->name.' : Client Listing';            
            $this->loadViews("client/client_list", $this->global, $data, NULL);
        //}
    }
	public function client_excel($row_no = 0)
    {		
			$voucher_issue = 'no';
			$search_data = $this->session->userdata('seardata');
			$config = $this->config_model->getConfig();                   
            $data['clientRecords'] = $this->client_model->client_list('',$config->per_page, $row_no,'','','',$voucher_issue,$search_data);           
            $this->load->view("client/client_excel",$data);
    }
	public function client_word($row_no = 0)
    {		
			$voucher_issue = 'no'; 
			$search_data = $this->session->userdata('seardata');                  
			$config = $this->config_model->getConfig();
            $data['clientRecords'] = $this->client_model->client_list('',$config->per_page, $row_no,'','','',$voucher_issue,$search_data);           
            $this->load->view("client/client_word",$data);
    }
	
        

    /**
     * This function is used to load the add new form
     */
    function add_client()
    {
		check_permission(4);
        /*if($this->isAdminUser() == TRUE)
        {
            $this->loadThis();
        }
        else
        {*/
            if($this->input->post()){
				//die('asdfaf');
				$data_to_store = array(
				'name'=>$this->input->post('name'),
				'last_name'=>$this->input->post('last_name'),
				'cnic'=>$this->input->post('cnic'),
				'sr_name'=>$this->input->post('sr_name'),
				'passport_issue_date'=>date_change_db($this->input->post('passport_issue_date')),
				'passport_exp_date'=>date_change_db($this->input->post('passport_exp_date')),
				'dob'=>date_change_db($this->input->post('date')),
				'ppno'=>$this->input->post('ppno'),
				'age_group'=>$this->input->post('age_group'),
				'visa_id'=>$this->input->post('visa_id'),
				'agent_id'=>$this->input->post('agent_id'),
				'account_pkg'=>$this->input->post('account_pkg'),
				'visa_company_id'=>$this->input->post('visa_company_id'),
				'group_code'=>$this->input->post('group_code'),
				'group_name'=>$this->input->post('group_name'),
				'document'=>($this->input->post('document'))?'yes':'no',
				);
				$this->client_model->add_client($data_to_store);
			}
			$config = $this->config_model->getConfig();
            $data['agentRecords'] = $this->hotel_other_model->agent_list_users();
			$data['visaCompanyRecords'] = $this->hotel_other_model->visaCompany_list();
            $this->global['pageTitle'] = $config->name.' : Add / Edit Client List';
            $this->loadViews("client/add_client", $this->global, $data, NULL);
        //}
    }
	
	function deleteClient()
    {
        if($this->isAdminUser() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id = $this->input->post('id');
            $client_info = array('isDeleted'=>1);
            
            $result = $this->client_model->deleteClient($id, $client_info);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
	function edit_client($clientId = NULL)
    {
		check_permission(4);
        if($this->isAdminUser() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            if($clientId == null)
            {
                redirect('client');
            }            
            $data['clientInfo'] = $this->client_model->getClientInfo($clientId);
            $config = $this->config_model->getConfig();
            $this->global['pageTitle'] = $config->name.' : Edit Client';
            $data['agentRecords'] = $this->hotel_other_model->agent_list_users();
			$data['visaCompanyRecords'] = $this->hotel_other_model->visaCompany_list();
			//echo $clientId;
			//print_r($data['clientInfo']);die();
            $this->loadViews("client/add_client", $this->global, $data, NULL);
        }
    }
	function editClient()
    {
        if($this->isAdminUser() == TRUE)
        {
            $this->loadThis();
        }
        else
        {   
			$clientId = $this->input->post('id');
            $this->form_validation->set_rules('name','Client Name','trim|required|max_length[128]|xss_clean');
            //$this->form_validation->set_rules('address','Address','trim|required');
            //$this->form_validation->set_rules('cnic','CNIC','trim|required');            
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit_client($clientId);
            }
            else
            {
					$data_to_store = array(
					'name'=>$this->input->post('name'),
					'last_name'=>$this->input->post('last_name'),
					'cnic'=>$this->input->post('cnic'),
					'sr_name'=>$this->input->post('sr_name'),
					'passport_issue_date'=>date_change_db($this->input->post('passport_issue_date')),
					'passport_exp_date'=>date_change_db($this->input->post('passport_exp_date')),
					'dob'=>date_change_db($this->input->post('date')),
					'ppno'=>$this->input->post('ppno'),
					'age_group'=>$this->input->post('age_group'),
					'visa_id'=>$this->input->post('visa_id'),
					'agent_id'=>$this->input->post('agent_id'),
					'account_pkg'=>$this->input->post('account_pkg'),
					'visa_company_id'=>$this->input->post('visa_company_id'),
					'group_code'=>$this->input->post('group_code'),
					'group_name'=>$this->input->post('group_name'),
					'document'=>($this->input->post('document'))?'yes':'no',
					);
					
                
                $result = $this->client_model->eidt_client($clientId,$data_to_store);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Client updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Client updation failed');
                }
                
                redirect('client');
            }
        }
    }
	
	function visaApprove(){
		$id = $this->input->post('id');
		$visa_info = array('visa_approve'=>'yes');
		$result = $this->client_model->visaApprove($id, $visa_info);            
		if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
		else { echo(json_encode(array('status'=>FALSE))); }
	}
	function visaNApprove(){
		$id = $this->input->post('id');
		$visa_info = array('visa_approve'=>'no');
		$result = $this->client_model->visaApprove($id, $visa_info);            
		if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
		else { echo(json_encode(array('status'=>FALSE))); }
	}
	
	function update_visa(){
		$id = $this->input->post('id');
		$visa_no = $this->input->post('visa_no');
		$visa_date = date_change_db($this->input->post('visa_date'));
		$visa_info = array('visa_no'=>$visa_no,'visa_date'=>$visa_date);
		$result = $this->client_model->visaApprove($id, $visa_info);            
		if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
		else { echo(json_encode(array('status'=>FALSE))); }
	}
	//////////////////////end client management ///////////////////////
	
	
	
	
	
	
	
	
    /**
     * This function is used to check whether email already exist or not
     */
    function checkPassportNo()
    {
        $ppno = $this->input->post("ppno");
		$id = $this->input->post("id");

        if(empty($id)){
            $result = $this->client_model->checkPassportNo($ppno);
        } else {
            $result = $this->client_model->checkPassportNo($ppno,$id);
        }
        if(empty($result)){ echo("true"); }
        else { echo("false"); }
    }
    
    /**
     * This function is used to add new user to the system
     */
    

    function pageNotFound()
    {
        $this->global['pageTitle'] = 'CodeInsect : 404 - Page Not Found';
        
        $this->loadViews("404", $this->global, NULL, NULL);
    }
}

?>