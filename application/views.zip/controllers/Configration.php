<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Configration (ConfigrationController)
 * 
 * @author : Muhammad Nadeem Ijaz
 * @version : 1.1
 * @since : 14 August 2018
 */
class Configration extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
		if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {  
		        
        $data['config'] = $res = $this->config_model->getConfig();
		$this->global['pageTitle'] = $res->name.' : Configration';
		//echo $res->name;die();
		if($this->input->post()){
			$data_to_update = array(
			'name'=>$this->input->post('name'),
			'address'=>$this->input->post('address'),
			'phone'=>$this->input->post('phone'),
			'phone2'=>$this->input->post('phone2'),
			'adult_rate'=>$this->input->post('adult_rate'),
			'child_rate'=>$this->input->post('child_rate'),
			'infant_rate'=>$this->input->post('infant_rate'),
			'per_page'=>$this->input->post('per_page'),
			'sr_rate'=>$this->input->post('sr_rate'),
			'no_vo_visa_rate'=>$this->input->post('no_vo_visa_rate'),
			'mad_name'=>$this->input->post('mad_name'),
			'mad_cont'=>$this->input->post('mad_cont'),
			'mad_name1'=>$this->input->post('mad_name1'),
			'mad_cont1'=>$this->input->post('mad_cont1'),
			'mak_name'=>$this->input->post('mak_name'),
			'mak_cont'=>$this->input->post('mak_cont'),
			'mak_name1'=>$this->input->post('mak_name1'),
			'mak_cont1'=>$this->input->post('mak_cont1'),
			'email'=>$this->input->post('email'),
			'member_one'=>$this->input->post('member_one'),
			'dis_one'=>$this->input->post('dis_one'),
			'member_two'=>$this->input->post('member_two'),
			'dis_two'=>$this->input->post('dis_two'),
			
			);
			
			
			if($_FILES["userfile"]["name"]){	
				$pic = $_FILES["userfile"]["tmp_name"];
				$p = explode('\\',$pic);
				$pic_name = substr($p[count($p)-1],5,-4).$_FILES["userfile"]["name"];
				$data_to_update['packeg1'] = $pic_name;
				
				move_uploaded_file($_FILES['userfile']['tmp_name'], 'assets/images/' . $pic_name);
				//echo $pic_name;die();
			}
			
			if($_FILES["userfile1"]["name"]){	
				$pic1 = $_FILES["userfile1"]["tmp_name"];
				$p1 = explode('\\',$pic1);
				$pic_name1 = substr($p[count($p1)-1],5,-4).$_FILES["userfile1"]["name"];
				$data_to_update['packeg2'] = $pic_name1;
				
				move_uploaded_file($_FILES['userfile1']['tmp_name'], 'assets/images/' . $pic_name1);
				//echo $pic_name;die();
			}
			
			
			$this->config_model->update($data_to_update);
			$data['config'] = $config = $this->config_model->getConfig();
		}
        $this->loadViews("configration", $this->global, $data , NULL);
		}
    }
	function agent_config()
	{
		if($this->isAgent() == TRUE)
        {
            $this->loadThis();
        }
        else
        {  
		$config = $this->config_model->getConfig();
        $this->global['pageTitle'] = $config->name.' : Account Setting';
        $data['config'] = $res = $this->config_model->agentConfig($this->session->userdata('userId'));
		//echo $res->name;die();
		if($this->input->post()){
						$data_to_update = array(
			'name'=>$this->input->post('name'),
			'c_name'=>$this->input->post('c_name'),
			'mobile'=>$this->input->post('mobile'),
			'address'=>$this->input->post('address'),
			);
			/*echo "<pre>";
			print_r($this->input->post());
			die();*/
			
			if($_FILES["userfile"]["name"]){	
				$pic = $_FILES["userfile"]["tmp_name"];
				$p = explode('\\',$pic);
				$pic_name = substr($p[count($p)-1],5,-4).$_FILES["userfile"]["name"];
				$data_to_update['logo'] = $pic_name;
				
				move_uploaded_file($_FILES['userfile']['tmp_name'], 'assets/images/' . $pic_name);
				//echo $pic_name;die();
			}
			$this->config_model->update_agent_config($data_to_update);
			$data['config'] = $res = $this->config_model->agentConfig($this->session->userdata('userId'));
		}
		
        $this->loadViews("agent_config", $this->global, $data , NULL);
		}
	}
	function backup_db()
    {
    		$this->load->dbutil();
    		$prefs = array(
				'format'      => 'zip',
				'filename'    => 'ams.sql'
    		);
    		 
    		$backup =& $this->dbutil->backup($prefs);
    		 
			$file_name = 'AlAbrarTravels-' . date("Y-m-d-H-i-s") .'.zip';
    		$save = 'uploads/'.$file_name;
    		$this->load->helper('download');
    		while (ob_get_level()) {
    			ob_end_clean();
    		}
    		force_download($file_name, $backup);
    }
    
    
}

?>