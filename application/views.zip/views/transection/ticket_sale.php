<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-credit-card"></i> Ticket Sale Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    
    <section class="content">
    <div class="row">
            <form action="<?php echo base_url() ?>ticket_sale" method="POST" id="">                
                <?php //print_r($this->session->userdata('searchdata'));
				$search = $this->session->userdata('searchdata');//echo $search['agent_id'];
				 if($this->session->userdata('role') != '3'){?>
                    <div class="col-md-2">
                    <select name="agent_id" class="form-control" id="agent_id">
                        <option value="">Select Agent</option>
                        <?php foreach($agentRecords as $row){?>
                            <option value="<?php echo $row->userId?>"<?php echo ($search['agent_id'] == $row->userId)?'selected="selected"':''?>><?php echo $row->name?></option>
                        <?php }?>
                    </select>
                    </div>
                    <?php }?>
                    <div class="col-md-2">
                    <select name="flight_id" class="form-control" id="flight_id">
                        <option value="">Select Flight</option>
                        <?php foreach($flights as $row){?>
                            <option value="<?php echo $row->id?>"<?php echo ($search['flight_id'] == $row->id)?'selected="selected"':''?>><?php echo $row->name?></option>
                        <?php }?>
                    </select>
                    </div>
                    <div class="col-md-2">                                
                        <div class="form-group">
                            <?php if(isset($search['bsp'])){
                                    $flight_bsp = $search['bsp'];
                                }
                                else{
                                    $flight_bsp = '';
                                }?>
                            <select name="bsp" class="form-control" id="bsp">
                            	<option value="">Select BSP</option>
                               <option value="no" <?php echo ($flight_bsp == 'no')?'selected="selected"':''?>>No</option>
                               <option value="yes" <?php echo ($flight_bsp == 'yes')?'selected="selected"':''?>>Yes</option>
                            </select> 
                        </div>                                    
                    </div>
                    <div class="col-md-2">
                            <input type="text" name="date_range" class="date_range_rep form-control" value="<?php echo ($search['date_range'])?$search['date_range']:''?>">
                        </div>
                    <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>
         </div>
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                <?php if($this->session->userdata('role') != 3){?>
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>addTicket_sale"><i class="fa fa-plus"></i> Add New</a>
                    <?php }?>
                </div>
            </div>
        </div>        
        
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                	<div class="row">
                    	<div class="col-md-3">
                    		<h3 class="box-title">Ticket Sale Detail</h3>
                        </div><form action="<?php echo base_url() ?>ticket_sale" method="POST" id="searchList">
                            
                                <button class="searchList"></button>
                        </form>
                </div>
                <a href='<?php echo base_url() ?>ticket_sale_excel/<?php echo $count?>'> <i class="fa fa-file-excel-o "> </i> </a>
				<a href='<?php echo base_url() ?>ticket_sale_word/<?php echo $count?>'> <i class="fa fa-file-word-o "> </i> </a>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-bordered table-striped dataTable table-hover">
                    <tr>
                    	<th>Sr#</th>
                    	<th>Date</th>
                          <th>Name</th>
                          <th>Ticket No</th>
                          <th>PNR</th>
                          <th>Air Line</th>
                          <th>Agent</th>
                          <th>Ticket From-To</th>
                          <th>Category</th>
                          <th>Ticket Khareed Rate</th>
                          <th>Ticket Sale Rate</th>
                          <th>Profit</th>
                          <?php if($this->session->userdata('role') != '3'){?>
                          <th>Action</th>
                          <?php }?>
                  <!--    <th class="text-center">Actions</th>-->
                    </tr>
                    <?php $total_purchase = 0;$total_sale = 0; $total_profit = 0;$profit = 0;//print_r($hotelRecords);
                    if(!empty($ticket_sale))
                    {
                        foreach($ticket_sale as $record)
                        {
							$count++;
							$total_purchase += $record->purchase;
							$total_sale += $record->sale;
							$profit = $record->sale-$record->purchase;
							$total_profit +=$profit;
                    ?>
                    <tr>
                     <td><?php echo $count ?></td>
                      <td><?php echo date_change_view($record->date) ?></td>
                      <td><?php echo $record->name ?></td>
                      <td><?php echo $record->ticket_no?></td>
                      <td><?php echo $record->pnr ?></td>
                      <td><?php echo $record->flight_name ?></td>
                      <td><?php echo $record->agent_name ?></td>
                      <td><?php echo $record->ticket_from_to ?></td>
                      <td><?php echo $record->category ?></td>
                      <td><?php echo $record->purchase ?></td>
                      <td><?php echo $record->sale ?></td>
                      <td><?php echo $record->sale-$record->purchase ?></td>
                      <?php if($this->session->userdata('role') != '3'){?>
                      <td class="text-center">
                          <a class="btn btn-sm btn-info" href="<?php echo base_url().'edit_ticketSale/'.$record->id; ?>"><i class="fa fa-pencil"></i></a>
                          <a class="btn btn-sm btn-danger deleteTicket" href="#" data-id="<?php echo $record->id; ?>"><i class="fa fa-trash"></i></a>
                      </td>
                      <?php }?>
                    </tr>
                    <?php
                        }
                    }
                    ?> 
                    <tr>
                    	<td colspan="2"></td>
                        <td>Total</td>
                        <td colspan="6"></td>
                        <td><?php echo $total_purchase?></td>
                        <td><?php echo $total_sale?></td>
                        <td><?php echo $total_profit?></td>
                        <td></td>
                    </tr>                   
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
        
        
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "ticket_sale/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
