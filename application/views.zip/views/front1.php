<!doctype html>
<html class="no-js"  lang="en">

	<head>
		<!-- META DATA -->
        <link rel="icon" type="image/png" href="<?php echo base_url()?>/icon.png"/>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Rufina:400,700" rel="stylesheet" />

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet" />

		<!-- TITLE OF SITE -->
		<title>Al Abrar Travels BWN</title>

		<!-- favicon img -->
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>

		<!--font-awesome.min.css-->
		<link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/font-awesome.min.css" />

		<!--animate.css-->
		<link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/animate.css" />

		<!--hover.css-->
		<link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/hover-min.css">

		<!--datepicker.css-->
		<link rel="stylesheet"  href="assets/css/datepicker.css" >

		<!--owl.carousel.css-->
        <link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/owl.theme.default.min.css"/>

		<!-- range css-->
        <link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/jquery-ui.min.css" />

		<!--bootstrap.min.css-->
		<link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/bootstrap.min.css" />

		<!-- bootsnav -->
		<link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/bootsnav.css"/>

		<!--style.css-->
		<link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/style.css" />

		<!--responsive.css-->
		<link rel="stylesheet" href="<?php echo base_url()?>front/assets/css/responsive.css" />

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

	</head>

	<body class="bg">
		<!--[if lte IE 9]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade
			your browser</a> to improve your experience and security.</p>
		<![endif]-->

		<!-- main-menu Start -->
		<header class="top-area">
			<div class="header-area">
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							<div class="logo">
								<a href="index.html">
									<!--Al Abrar <span>Travels</span>-->
                                    <img style=" width:100px" src="<?php echo base_url()?>assets/images/31ALABRAR.png" alt="Al Abraar Travels" />
								</a>
							</div><!-- /.logo-->
						</div><!-- /.col-->
						<div class="col-sm-10">
							<div class="main-menu">
							
								<!-- Brand and toggle get grouped for better mobile display -->
								<div class="navbar-header">
									<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
										<i class="fa fa-bars"></i>
									</button><!-- / button-->
								</div><!-- /.navbar-header-->
								<div class="collapse navbar-collapse">		  
									<ul class="nav navbar-nav navbar-right">
										<li class="smooth-menu"><a href="#home">home</a></li>
										<li class="smooth-menu"><a href="#gallery">About Us</a></li>
										<li class="smooth-menu"><a href="#pack">Packages </a></li>
										
									</ul>
								</div><!-- /.navbar-collapse -->
							</div><!-- /.main-menu-->
						</div><!-- /.col-->
					</div><!-- /.row -->
					<div class="home-border"></div><!-- /.home-border-->
				</div><!-- /.container-->
			</div><!-- /.header-area -->

		</header><!-- /.top-area-->
		<!-- main-menu End -->

		
		<!--about-us start -->
		<section id="home" class="about-us">
			<div class="container">
				<div class="about-us-content">
					<div class="row">
						<div class="col-sm-8">
							<div class="single-about-us">
								<div class="about-us-txt">
									<h2>
										Welcome to Al Abrar Travels Bahawalnagar

									</h2>
									<!--<div class="about-btn">
										<button  class="about-view">
											explore now
										</button>
									</div>--><!--/.about-btn-->
								</div><!--/.about-us-txt-->
							</div><!--/.single-about-us-->
						</div><!--/.col-->
                        <div class="col-md-4">
                        	
                            
                            
                            
                            <div class="row">
            <div class="col-md-12">
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
            </div>
        </div>
        <?php
        $this->load->helper('form');
        $error = $this->session->flashdata('error');
        if($error)
        {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error; ?>                    
            </div>
        <?php }
        $success = $this->session->flashdata('success');
        if($success)
        {
            ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $success; ?>                    
            </div>
        <?php } ?>
        
        <form action="<?php echo base_url(); ?>loginMe" method="post">
          <div class="form-group has-feedback">
            <input type="email" class="form-control" placeholder="Email" name="email" required />
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="password" required />
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-8">    
              <!-- <div class="checkbox icheck">
                <label>
                  <input type="checkbox"> Remember Me
                </label>
              </div>  -->                       
            </div><!-- /.col -->
            <div class="col-xs-4">
              <input type="submit" class="btn btn-primary btn-block btn-flat" value="Sign In" />
            </div><!-- /.col -->
          </div>
        </form>
                            
                            
                            
                            
                            
                        </div>
						<div class="col-sm-0">
							<div class="single-about-us">
								
							</div><!--/.single-about-us-->
						</div><!--/.col-->
					</div><!--/.row-->
				</div><!--/.about-us-content-->
			</div><!--/.container-->

		</section><!--/.about-us-->
		<!--about-us end -->

		<!--travel-box start-->
		<section  class="travel-box">
        	<div class="container">
        		<div class="row">
        			<div class="col-md-12">
        				<div class="single-travel-boxes">
        					<div id="desc-tabs" class="desc-tabs">
								<div class="gallary-header text-center">
                                	<h1>Al Abrar Travels & Tours Pvt Ltd</h1>
                                    <p style="padding:30px; line-height:2">
                                    	We provide travel and tour services specializing in umrah. Our current client base is spread through out Pakistan through our sub-agents and direct customers. Details of services we provide are available in services section. In addition you can view different type of packages in order to select suitable package for you and your family. We also have a collection of detailed and authentic information on different religious procedures in our counseling section of website.
                                    </p>
                                    <h5>To know more about “What we Offer”:</h5>
                                    <h4>Email us at :<?php echo $config->email?></h4>
									<h4>Phone No :   <?php echo $config->phone?></h4>
                                    <h4>Phone No :   <?php echo $config->phone2?></h4>
                                </div>
								




							</div><!--/.desc-tabs-->
        				</div><!--/.single-travel-box-->
        			</div><!--/.col-->
        		</div><!--/.row-->
        	</div><!--/.container-->

        </section><!--/.travel-box-->
		<!--travel-box end-->

		<!--galley start-->
		<section id="gallery" class="gallery">
			<div class="container">
				<div class="gallery-details">
					<div class="gallary-header text-center">
						<h2>
							About Us
						</h2>
						<p>
							Al Abrar Travels and Tours Pvt Ltd.We provide travel and tour services specializing in Umrah.
                            To Know more about us Plese contact us at 
						</p>
                        <h2><?php echo $config->email?></h2>
                        <h3>Phone: <?php echo $config->phone?></h3>
                        <h3>Phone: <?php echo $config->phone2?></h3>
					</div><!--/.gallery-header-->
					<!--<div class="gallery-box">
						<div class="gallery-content">
						  	<div class="filtr-container">
						  		<div class="row">

						  			<div class="col-md-6">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g1.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													china
												</a>
												<p><span>20 tours</span><span>15 places</span></p>
											</div><!-- /.item-title --
										</div><!-- /.filtr-item --
						  			</div><!-- /.col --

						  			<div class="col-md-6">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g2.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													venuzuala
												</a>
												<p><span>12 tours</span><span>9 places</span></p>
											</div> <!-- /.item-title--
										</div><!-- /.filtr-item --
						  			</div><!-- /.col --

						  			<div class="col-md-4">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g3.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													brazil
												</a>
												<p><span>25 tours</span><span>10 places</span></p>
											</div><!-- /.item-title --
										</div><!-- /.filtr-item --
						  			</div><!-- /.col --

						  			<div class="col-md-4">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g4.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													australia 
												</a>
												<p><span>18 tours</span><span>9 places</span></p>
											</div> <!-- /.item-title--
										</div><!-- /.filtr-item --
						  			</div><!-- /.col --

						  			<div class="col-md-4">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g5.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													netharland
												</a>
												<p><span>14 tours</span><span>12 places</span></p>
											</div> <!-- /.item-title--
										</div><!-- /.filtr-item --
						  			</div><!-- /.col --

						  			<div class="col-md-8">
						  				<div class="filtr-item">
											<img src="assets/images/gallary/g6.jpg" alt="portfolio image"/>
											<div class="item-title">
												<a href="#">
													turkey
												</a>
												<p><span>14 tours</span><span>6 places</span></p>
											</div> <!-- /.item-title--
										</div><!-- /.filtr-item --
						  			</div><!-- /.col --

						  		</div><!-- /.row --

						  	</div><!-- /.filtr-container--
						</div><!-- /.gallery-content --
					</div>--><!--/.galley-box-->
				</div><!--/.gallery-details-->
			</div><!--/.container-->

		</section><!--/.gallery-->
		<!--gallery end-->



		<!--packages start-->
		<section id="pack" class="packages">
			<div class="container">
				<div class="gallary-header text-center">
					<h2>
						special packages
					</h2>
					<p>
						Here are some Special packegs
					</p>
				</div><!--/.gallery-header-->
				<div class="packages-content">
					<div class="row">

						<div class="col-md-4 col-sm-6">
							<div class="single-package-item">
								<!--<img src="assets/images/packages/p1.jpg" alt="package-place">-->
								<div class="single-package-item-txt">
									<h3>Umrah 14 days <span class="pull-right">Rs.<?php echo $config->rate_one?></span></h3>
									<div class="packages-para">
										<p>
											<span>
												<i class="fa fa-angle-right"></i> 14 daays 14 nights
											</span>
											<i class="fa fa-angle-right"></i>  5 star accomodation
										</p>
										<p>
											<span>
												<i class="fa fa-angle-right"></i>  transportation
											</span>
											<i class="fa fa-angle-right"></i>  ziarat
										 </p>
									</div><!--/.packages-para-->									
								</div><!--/.single-package-item-txt-->
							</div><!--/.single-package-item-->
						</div><!--/.col-->
                        <div class="col-md-4 col-sm-6">
							<div class="single-package-item">
								<!--<img src="assets/images/packages/p1.jpg" alt="package-place">-->
								<div class="single-package-item-txt">
									<h3>Umrah 21 days <span class="pull-right">Rs.<?php echo $config->rate_two?></span></h3>
									<div class="packages-para">
										<p>
											<span>
												<i class="fa fa-angle-right"></i> 21 daays 21 nights
											</span>
											<i class="fa fa-angle-right"></i>  5 star accomodation
										</p>
										<p>
											<span>
												<i class="fa fa-angle-right"></i>  transportation
											</span>
											<i class="fa fa-angle-right"></i>  ziarat
										 </p>
									</div><!--/.packages-para-->									
								</div><!--/.single-package-item-txt-->
							</div><!--/.single-package-item-->
						</div><!--/.col-->
                        <div class="col-md-4 col-sm-6">
							<div class="single-package-item">
								<!--<img src="assets/images/packages/p1.jpg" alt="package-place">-->
								<div class="single-package-item-txt">
									<h3>Umrah 28 days <span class="pull-right">Rs.<?php echo $config->rate_three?></span></h3>
									<div class="packages-para">
										<p>
											<span>
												<i class="fa fa-angle-right"></i> 28 daays 28 nights
											</span>
											<i class="fa fa-angle-right"></i>  5 star accomodation
										</p>
										<p>
											<span>
												<i class="fa fa-angle-right"></i>  transportation
											</span>
											<i class="fa fa-angle-right"></i>  ziarat
										 </p>
									</div><!--/.packages-para-->									
								</div><!--/.single-package-item-txt-->
							</div><!--/.single-package-item-->
						</div><!--/.col-->
                        

						<!--/.col-->
						
						<!--/.col-->
						
						<!--/.col-->
						
						<!--/.col-->
						
						<!--/.col-->

					</div><!--/.row-->
				</div><!--/.packages-content-->
			</div><!--/.container-->

		</section><!--/.packages-->
		<!--packages end-->

		<!-- testemonial Start -->
		<!--/.testimonial-->	
		<!-- testemonial End -->


		<!--special-offer start-->
		<!--/.special-offer end-->
		<!--special-offer end-->

		<!--blog start-->
		<!--/.blog-->
		<!--blog end-->

		
		<!--subscribe start-->
		
		<!--subscribe end-->

		<!-- footer-copyright start -->
		<footer  class="footer-copyright bg">
			<div class="container">
				<div class="footer-content">
					<div class="row">

						<div class="col-sm-3">
							<div class="single-footer-item">
								<div class="footer-logo">
									<a href="index.html">
										Al Abrar Travels<span>Bahawalnagar</span>
									</a>
									<p>
										best travel agency
									</p>
								</div>
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

						<div class="col-sm-4">
							<div class="single-footer-item">
								<h2>link</h2>
								<div class="single-footer-txt">
									<p><a href="#">home</a></p>
									<p><a href="#">About Us</a></p>
									<p><a href="#">Packeges</a></p>
								</div><!--/.single-footer-txt-->
							</div><!--/.single-footer-item-->

						</div><!--/.col-->

						

						<div class="col-sm-4">
							<div class="single-footer-item text-center">
								<h2 class="text-left">contacts</h2>
								<div class="single-footer-txt text-left">
									<p><?php echo $config->phone?></p>
                                    <p><?php echo $config->phone2?></p>
									<p class="foot-email"><p><?php echo $config->email?></p></p>
									<p><?php echo $config->address?></p>
								</div><!--/.single-footer-txt-->
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

					</div><!--/.row-->

				</div><!--/.footer-content-->
				<hr>
				<div class="foot-icons ">
					<ul class="footer-social-links list-inline list-unstyled">
		                <li><a href="#" target="_blank" class="foot-icon-bg-1"><i class="fa fa-facebook"></i></a></li>
		                <li><a href="#" target="_blank" class="foot-icon-bg-2"><i class="fa fa-twitter"></i></a></li>
		                <li><a href="#" target="_blank" class="foot-icon-bg-3"><i class="fa fa-instagram"></i></a></li>
		        	</ul>
		        	<p>&copy; 2018-19 Developed By Muhammad Nadeem Ijaz Mob:03017893497 All Right Reserved</p>

		        </div><!--/.foot-icons-->
				<div id="scroll-Top">
					<i class="fa fa-angle-double-up return-to-top" id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div><!--/.scroll-Top-->
			</div><!-- /.container-->

		</footer><!-- /.footer-copyright-->
		<!-- footer-copyright end -->




		<script src="<?php echo base_url()?>front/assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->

		<!--modernizr.min.js-->
		<script  src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>


		<!--bootstrap.min.js-->
		<script  src="<?php echo base_url()?>front/assets/js/bootstrap.min.js"></script>

		<!-- bootsnav js -->
		<script src="<?php echo base_url()?>front/assets/js/bootsnav.js"></script>

		<!-- jquery.filterizr.min.js -->
		<script src="<?php echo base_url()?>front/assets/js/jquery.filterizr.min.js"></script>

		<script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

		<!--jquery-ui.min.js-->
        <script src="<?php echo base_url()?>front/assets/js/jquery-ui.min.js"></script>

        <!-- counter js -->
		<script src="<?php echo base_url()?>front/assets/js/jquery.counterup.min.js"></script>
		<script src="<?php echo base_url()?>front/assets/js/waypoints.min.js"></script>

		<!--owl.carousel.js-->
        <script  src="<?php echo base_url()?>front/assets/js/owl.carousel.min.js"></script>

        <!-- jquery.sticky.js -->
		<script src="<?php echo base_url()?>front/assets/js/jquery.sticky.js"></script>

        <!--datepicker.js-->
        <script  src="<?php echo base_url()?>front/assets/js/datepicker.js"></script>

		<!--Custom JS-->
		<script src="<?php echo base_url()?>front/assets/js/custom.js"></script>


	</body>

</html>