


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta charset="utf-8" />
<link rel="icon" type="image/png" href="<?php echo base_url()?>icon.png"/>
<title>
	Al Abrar Travels
</title><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta name="description" content="Al Abrar Travels" /><meta name="author" content="Al Travels Travels" />
    <!-- google web fonts -->
    

    <!-- CSS Styles -->
    <!-- bootstrap css -->
    <link href="<?php echo base_url()?>front/css/bootstrap.css" rel="stylesheet" />

    <!-- custom css -->
    <link href="<?php echo base_url()?>front/css/custom.css" rel="stylesheet" />



    <!-- standart theme css -->
    <link id="theme" rel="stylesheet" href="<?php echo base_url()?>front/css/theme1.css" type="text/css" />

    <!-- Font Awesome Icons css -->
    <link rel="stylesheet" href="<?php echo base_url()?>front/font-awesome/css/font-awesome.min.css" />

    <!-- BxSlider and Sequence Slider css -->
    <link rel="stylesheet" href="<?php echo base_url()?>front/css/jquery.bxslider.css" type="text/css" />
    <link rel="stylesheet" media="screen" href="<?php echo base_url()?>front/css/sequence-slider.css" />

    <!-- Magnific Popup core CSS file -->
    <link rel="stylesheet" href="<?php echo base_url()?>front/css/magnific-popup.css" />

    <!-- Color Switch Panel css -->
    <link rel="stylesheet" href="<?php echo base_url()?>front/css/color.switch.css" type="text/css" />

    <!-- Back to Top Button css -->
    <link rel="stylesheet" href="<?php echo base_url()?>front/css/top.css" type="text/css" />
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->


    <!--[if lt IE 9]>
      <script src="../js/html5shiv.js"></script>
    <![endif]-->


    <!-- Fav and touch icons -->
    <!--<link rel="shortcut icon" href="./img/favicon.ico" /><link rel="apple-touch-icon" href="./img/apple-touch-icon.png" /><link rel="apple-touch-icon" sizes="72x72" href="./img/apple-touch-icon-72x72.png" /><link rel="apple-touch-icon" sizes="114x114" href="./img/apple-touch-icon-114x114.png" />-->



</head>
<body>



        <div>

            <!-- START PRIMARY LAYOUT
        ======================== -->
            <!-- Back to Top Button (visible after scrolling 1200px down) Change Styles at the top.css file -->
            <div class="button-top" id="top-bt">
                <a href="#about"><i class="fa fa-sort-asc fa-3x"></i></a>

            </div>
            <!-- Back to Top Button END -->
            <!-- NAVBAR -->
            <!-- Wrap the .navbar in .container to center it within the absolutely positioned parent. -->
            <nav class="navbar navbar-inverse navbar-static-top" role="navigation" id="menu">            	
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <!-- MENU LINKS -->
                    <div class="row">
						<div class="col-sm-2">
							<div class="logo">
								<a href="#">
									<!--Al Abrar <span>Travels</span>-->
                                    <img style=" width:100px" src="<?php echo base_url()?>front/img/alabrar.png" alt="Al Abraar Travels" />
								</a>
							</div><!-- /.logo-->
						</div>
                        <div class="col-sm-8">
                            <div id="navbar" class="navbar-collapse collapse">
                                <ul class="nav navbar-nav" id="navigation">
                                    <li><a href="#about">About</a></li>
                                    <li><a href="#service">Service</a></li>
                                    <li><a href="#price">Price</a></li>
                                    <li><a href="#umrah">Umrah Package</a></li>
                                    <li><a href="#team">Team</a></li>
                                    <li><a href="#clients">Clients</a></li>
                                    <li><a href="#contact">Contact</a></li>
                                </ul>
                            </div>
                    	</div>
                        <div class="col-sm-2">
							<div class="logo">
								<a href="#">
									<!--Al Abrar <span>Travels</span>-->
                                    <img style=" width:100px" src="<?php echo base_url()?>front/img/vector-iata.png" alt="IATA logo" />
								</a>
							</div><!-- /.logo-->
						</div>
                    </div>
                </div>                
            </nav>




            <!-- NAVBAR END -->
            <!-- SEQUENCE SLIDER Change Styles at the sequence-slider.css file -->
            <div id="top-slider">
                <div class="slider-bg"></div>
                <div class="container">

                    <div id="sequence">
                        <img class="sequence-prev" src="<?php echo base_url()?>front/img/previous.png" alt="Previous Frame" />
                        <img class="sequence-next" src="<?php echo base_url()?>front/img/next.png" alt="Next Frame" />
                        <ul class="sequence-canvas">
                            <li class="animate-in">
                                <h2 class="title">Al Abrar Travels</h2>
                                <h3 class="subtitle">Wellcome to Al Abrar Travels Bahawalnagar</h3>
                                <img class="slider-image" src="<?php echo base_url()?>front/img/slider_1.png" alt="Image" />
                            </li>
                            <li>
                                <h2 class="title">Umrah</h2>
                                <h3 class="subtitle">Looking for Cheap Umrah Packages? </h3>
                                <img class="slider-image" src="<?php echo base_url()?>front/img/slider_2.png" alt="Image" />
                            </li>
                            <li>
                                <h2 class="title">Ticketing</h2>
                                <h3 class="subtitle">Do you want cheap ticket on flights</h3>
                                <img class="slider-image" src="<?php echo base_url()?>front/img/slider_3.png" alt="Image" />
                            </li>
                        </ul>
                        <ul class="sequence-pagination">
                            <li>
                                <img src="./img/pagination-dot.svg" alt="Image" /></li>
                            <li>
                                <img src="./img/pagination-dot.svg" alt="Image" /></li>
                            <li>
                                <img src="./img/pagination-dot.svg" alt="Image" /></li>
                        </ul>

                    </div>

                </div>
            </div>
            
            <!-- SEQUENCE SLIDER END -->
            <!-- ABOUT US -->

            <div id="about">
                <div class="container">



                    <div class="center-block head">

                        <h1>About Us</h1>
                        <hr class="head-border-grey" />

                    </div>

                    <div class="agency col-lg-5 col-lg-offset-1 col-md-5 col-md-offset-1">
                        <p>Welcome to the Al Abrar Travels & Tours.We provide travel and tour services specializing in Umrah. Our current client base is spread through out Pakistan through our sub-agents and direct customers.
                        </p><p> Details of services we provide are available in services section. In addition you can view different type of packages in order to select suitable package for you and your family.</p>
                        <p> We also have a collection of detailed and authentic information on different religious procedures in our counseling section of website.</p>

                    </div>

                    <!-- About Us Slider. Change Styles at the jquery.bxlsider.css file -->
                    <div class="col-lg-5 col-md-5">
                    <div class="row">
            <div class="col-md-12">
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
            </div>
        </div>
        <?php
        $this->load->helper('form');
        $error = $this->session->flashdata('error');
        if($error)
        {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error; ?>                    
            </div>
        <?php }
        $success = $this->session->flashdata('success');
        if($success)
        {
            ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $success; ?>                    
            </div>
        <?php } ?>
        
        <form action="<?php echo base_url(); ?>loginMe" method="post">
          <div class="form-group has-feedback">
            <input type="email" class="form-control" placeholder="Email" name="email" required />
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="password" required />
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-8">    
              <!-- <div class="checkbox icheck">
                <label>
                  <input type="checkbox"> Remember Me
                </label>
              </div>  -->                       
            </div><!-- /.col -->
            <div class="col-xs-4">
              <input type="submit" class="btn btn-primary btn-block btn-flat" value="Sign In" />
            </div><!-- /.col -->
          </div>
        </form><a href="<?php echo base_url() ?>forgotPassword">Forgot Password</a><br>
                        <ul class="aboutus">

                            <li>
                                <img class="img-responsive" src="<?php echo base_url()?>front/img/pia_1.jpg" alt="YOUR TEXT HERE" />
                            </li>

                            <li>
                                <img class="img-responsive" src="<?php echo base_url()?>front/img/pia_2.jpg" alt="YOUR TEXT HERE" />
                            </li>

                            <li>
                                <img class="img-responsive" src="<?php echo base_url()?>front/img/pia_3.jpg" alt="YOUR TEXT HERE" />
                            </li>

                        </ul>
                    </div>

                </div>
            </div>
            <!-- ABOUT END -->
            <!-- SERVICE -->

            <div id="service">
                <div class="container">
                    <div class="row">

                        <div class="center-block head">

                            <div class="col-lg-12 col-md-12 col-xs-12">

                                <h1>What We Do</h1>
                                <hr class="head-border-white" />
                               
                            </div>

                        </div>

                        <!-- SERVICE COLUMNS -->
                        <div class="col-lg-4 col-md-4 service">
                            <div class="service-col">

                                <div class="icon-desktop rotate">
                                    <img src="<?php echo base_url()?>front/img/visa_hotel.png" style="border-radius: 50%; height: 140px; width: 140px" alt="visit visa" />
                                </div>

                                <h4>Vist Visa & Hotel Booking</h4>
                                <p>We provide visit visa at every where in the world. We can also provide cheap and very low rate vist visa and hotel residence. Our servisec are any time 24/7.</p>

                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 service">
                            <div class="service-col">

                                <div class="icon-wrench rotate">
                                    <img src="<?php echo base_url()?>front/img/umrah.png" style="border-radius: 50%; height: 140px; width: 140px" alt="Umrah" />
                                </div>

                                <h4>Umrah</h4>
                                <p>Looking for Cheap Umrah Packages? You are indeed at the right place. Through its well linked network Al Abrar Travels provides the Umrah services at the cheapest rates available in the market. Not only this, Al Abrar Travels also promises the best value for your money.</p>

                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 service">
                            <div class="service-col">

                                <div class="icon-mobile rotate">
                                    <img src="<?php echo base_url()?>front/img/ticket.png" style="border-radius: 50%; height: 140px; width: 140px" alt="Ticketing" />
                                </div>

                                <h4>Ticketing</h4>
                                <p>
                                    Book cheap air tickets . Get best deals on flight booking of domestic flights, airfare deals, cheap flight tickets with best price guarantee!<br />
                                    <br />
                                    <br />
                                    <br />
                                </p>

                            </div>
                        </div>
                    </div>
                    <div class="center-block service-btn">
                        <p class="center"><a class="btn btn-hire btn-primary" href="#contact" role="button">Contact Us Now!</a></p>
                    </div>


                </div>
            </div>
            <!-- SERVICE END -->
            <!-- PRICE -->
            <div id="price">
                <div class="container">
                    <div class="row">

                        <div class="center-block head tables">

                            <div class="col-lg-12 col-md-12 col-xs-12">

                                <h1>Best Price Guranteed</h1>
                                <hr class="head-border-grey" />

                            </div>

                        </div>

                        <!-- PRICE TABLES -->
                        <div class="col-lg-3 col-md-3">
                            <div class="price-table">
                                <div class="price-table-heading">
                                    <h3 class="price-table-title lead d-grey">Budget
                                    </h3>
                                </div>
                                <div class="price-table-body">
                                    <div class="the-price white">
                                        <h1>Lowest
                                          
                                        </h1>
                                        <small>Rates</small>
                                    </div>
                                    <table class="table">
                                        <tr>
                                            <td class="white">14 Nights
                                            </td>
                                        </tr>
                                        <tr class="active">
                                            <td class="blue">20 Nights
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="white">27 Nights
                                            </td>
                                        </tr>

                                    </table>
                                </div>
                                <div class="price-table-footer">
                                    <a href="#contact" class="btn btn-lg btn-primary" role="button">Sign Up</a>
                                </div>
                            </div>
                        </div>

                        <!-- TABLE 2 -->
                        <div class="col-lg-3 col-md-3">
                            <div class="price-table">
                                <div class="price-table-heading">
                                    <h3 class="price-table-title lead d-grey">Economy
                                    </h3>
                                </div>
                                <div class="price-table-body">
                                    <div class="the-price white">
                                        <h1>Low
                                        </h1>
                                        <small>Rates</small>
                                    </div>
                                    <table class="table">
                                        <tr>
                                            <td class="white">14 Nights
                                            </td>
                                        </tr>
                                        <tr class="active">
                                            <td class="blue">20 Nights
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="white">27 Nights
                                            </td>
                                        </tr>

                                    </table>
                                </div>
                                <div class="price-table-footer">
                                    <a href="#contact" class="btn btn-lg btn-primary" role="button">Sign Up</a>
                                </div>
                            </div>
                        </div>
                        <!-- TABLE 3 -->
                        <div class="col-lg-3 col-md-3">
                            <div class="price-table table-feature">
                                <div class="price-table-heading">
                                    <h3 class="price-table-title lead d-grey">Silver
                                    </h3>
                                </div>
                                <div class="price-table-body">
                                    <div class="the-price white">
                                        <h1>Medium
                                        </h1>
                                        <small>Rates</small>
                                    </div>
                                    <table class="table">
                                        <tr>
                                            <td class="white">14 Nights
                                            </td>
                                        </tr>
                                        <tr class="active">
                                            <td class="blue">20 Nights
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="white">27 Nights
                                            </td>
                                        </tr>

                                    </table>
                                </div>
                                <div class="price-table-footer">
                                    <a href="#contact" class="btn btn-lg btn-primary" role="button">Sign Up</a>
                                </div>
                            </div>
                        </div>

                        <!-- TABLE 4 -->
                        <div class="col-lg-3 col-md-3">
                            <div class="price-table">
                                <div class="price-table-heading">
                                    <h3 class="price-table-title lead d-grey">Golden
                                    </h3>
                                </div>
                                <div class="price-table-body">
                                    <div class="the-price white">
                                        <h1>High
                                        </h1>
                                        <small>Rates</small>
                                    </div>
                                    <table class="table">
                                        <tr>
                                            <td class="white">14 Nights
                                            </td>
                                        </tr>
                                        <tr class="active">
                                            <td class="blue">20 Nights
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="white">27 Nights
                                            </td>
                                        </tr>

                                    </table>
                                </div>
                                <div class="price-table-footer">
                                    <a href="#contact" class="btn btn-lg btn-primary" role="button">Sign Up</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- PRICE END -->

            

            



            


                 

            <div id="umrah">
                <div class="center-block head">

                    <div class="col-lg-12 col-md-12 col-xs-12">

                        <h1>Umrah Package</h1>
                        <hr class="head-border-white" />

                    </div>

                </div>

                <div>
                    <img alt="" id="img4" style="max-width: 600px" src="<?php echo base_url().'assets/images/'.$config->packeg1 ?>" />
                    <img alt="" id="img4" style="max-width: 600px" src="<?php echo base_url().'assets/images/'.$config->packeg2 ?>" />
                </div>


            </div>



            
            <div id="team">
                <div class="container">
                    <div class="row">

                        <div class="center-block head">

                            <div class="col-lg-12 col-md-12 col-xs-12">

                                <h1 class="">Our Team</h1>
                                <hr class="head-border-white" />


                            </div>

                        </div>

                        <!-- TEAM MEMBER -->
                        <div class="col-lg-3 col-md-3"></div>

                        <div class="col-lg-3 col-md-3">
                            <div class="team team-member1">

                                <div class="member1 rotate"></div>
                                <h5><?php echo $config->member_one?></h5>

                                <p>
                                    <?php echo $config->dis_one?><br />
                                    <br />
                                    <br />
                                </p>

                                <p class="social-team">
                                    <a class="facebook" href="#"><i class="fa fa-facebook-square fa-1-5x"></i></a>
                                    <a class="twitter" href="#"><i class="fa fa-twitter-square fa-1-5x"></i></a>
                                    <a class="linkedin" href="#"><i class="fa fa-linkedin-square fa-1-5x"></i></a>
                                    <a class="pinterest" href="#"><i class="fa fa-pinterest-square fa-1-5x"></i></a>
                                    <a class="instagram" href="#"><i class="fa fa-instagram fa-1-5x"></i></a>
                                </p>

                            </div>

                        </div>

                        <div class="col-lg-3 col-md-3">
                            <div class="team team-member2">

                                <div class="member2 rotate"></div>

                                <h5><?php echo $config->member_two?></h5>

                                <p><?php echo $config->dis_two?></p>

                                <p class="social-team">
                                    <a class="facebook" href="#"><i class="fa fa-facebook-square fa-1-5x"></i></a>
                                    <a class="twitter" href="#"><i class="fa fa-twitter-square fa-1-5x"></i></a>
                                    <a class="linkedin" href="#"><i class="fa fa-linkedin-square fa-1-5x"></i></a>
                                    <a class="pinterest" href="#"><i class="fa fa-pinterest-square fa-1-5x"></i></a>
                                    <a class="instagram" href="#"><i class="fa fa-instagram fa-1-5x"></i></a>
                                </p>

                            </div>

                        </div>
                        <div class="col-lg-3 col-md-3"></div>
                       
                    </div>
                </div>
            </div>

            <!-- CLIENTS -->
            <div id="clients">
                <div class="container">
                    <div class="row">

                        <div class="center-block head">

                            <div class="col-lg-12 col-md-12 col-xs-12">

                                <h1>What Our Clients Say</h1>
                                <hr class="head-border-grey" />


                            </div>

                        </div>

                        <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2">

                            <ul class="testemonials">

                                <li>
                                    <blockquote>
                                        <p><i>Al Abrar Travels & Tours is very cheap and relaiable. They provide all facilities as the said in packeg.</i></p>
                                        <p class="author">Muhammad Nadeem Ijaz</p>
                                    </blockquote>
                                </li>

                                <li>
                                    <blockquote>
                                        <p><i>5 Star Service! Cheapest Ticket To Saudia was provided by Al Abrar Travels. 100% reliable!</i></p>
                                        <p class="author">Aqsam Ali</p>
                                    </blockquote>
                                </li>

                                <li>
                                    <blockquote>
                                        <p><i>I have been using Al Abrar Travels from 7 years  and absolutely love it. Either its trip to Saudia or any Other place Its always a charm. Thank you.</i></p>
                                        <p class="author">Tanzeal Sarwar</p>
                                    </blockquote>
                                </li>

                            </ul>

                        </div>

                    </div>
                </div>
            </div>
            <!-- CLIENTS END -->
            <!-- GOOGLE MAP DIVIDER -->
            <div id="map">
            </div>
            <!-- GOOGLE MAP DIVIDER END -->
            <!-- CONTACT -->
            <div id="contact">
                <div class="container">
                    <div class="row">

                        <div class="center-block head">

                            <div class="col-lg-12 col-md-12 col-xs-12">

                                <h1>Get in Touch</h1>
                                <hr class="head-border-grey" />

                            </div>

                        </div>
                        <div class="col-lg-4 col-md-4 head">




                            <p>
                                <span class="fa fa-hand-o-right " aria-hidden="true"></span>&nbsp;Bahawalnagar:<br />
                            </p>
                            <p>
                                <span class="fa fa-briefcase " aria-hidden="true"></span>&nbsp;<?php echo $config->name?><br />
                            </p>
                            <p>
                                <span class="fa fa-home" aria-hidden="true"></span>&nbsp;<?php echo $config->address?><br />
                            </p>
                            <p>
                                <span class="fa fa-phone" aria-hidden="true"></span>&nbsp;<?php echo $config->phone?>,<?php echo $config->phone2?><br />
                            </p>                            
                            <br />
                            <!--<p>
                                <span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;M. Asghar Shaikh (Chairman)<br />
                            </p>
                            <p>
                                <span class="glyphicon glyphicon-phone" aria-hidden="true"></span>&nbsp;0300-8509350<br />
                            </p>
                            <br />
                            <p>
                                <span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;M. Akbar Shaikh (Executive Director)<br />
                            </p>
                            <p>
                                <span class="glyphicon glyphicon-phone" aria-hidden="true"></span>&nbsp;Mob. 0321-9515736<br />
                            </p>-->

                            <p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>&nbsp;<?php echo $config->email?></p>
                            
                        </div>

                        <!-- CONTACT FORM -->
                        <!--<div class="col-lg-8 col-md-8  form">




                            <div class="form-horizontal" id="contactForm">

                                <div class="form-group">

                                    <div class="col-sm-12">

                                        <input name="name" type="text" id="name" class="form-control input-lg" placeholder="Name*" />
                                        
                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-sm-12">
                                        <input name="email" type="email" id="email" class="form-control input-lg" placeholder="Email*" />
                                        
                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-sm-12">
                                        <input name="phone" type="number" id="phone" class="form-control input-lg" placeholder="Phone" />
                                        
                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-sm-12">
                                        <textarea name="message" rows="10" cols="20" id="message" class="form-control input-lg" placeholder="Message*">
</textarea>
                                        
                                    </div>
                                </div>

                                <div class="control-group submit center">

                                    <input type="submit" name="Submit" value="Submit" id="Submit" class="btn btn-lg btn-primary" />
                                    <span id="lblinfo" style="color:Red;"></span>
                                </div>
                            </div>



                        </div>-->

                    </div>
                </div>
            </div>
            <!-- CONTACT END -->
            <!-- GOING UP ARROW -->
            <div class="col-lg-12">
                <div class="up"><a href="#about"><span class="glyphicon glyphicon-chevron-up"></span></a></div>
            </div>
            <!-- GOING UP ARROW END -->
            <!-- SOCIAL MEDIA DIVIDER -->
            <div id="divider">
                <div class="divider-bg"></div>
                <div class="container">

                    <div class="row">
                        <div class="col-12-lg social-media">

                            <div class="social-icons">

                                <a class="social-media facebook" href="#"><i class="fa fa-facebook-square fa-8x"></i></a>
                                <a class="social-media white twitter" href="#"><i class="fa fa-twitter-square fa-8x"></i></a>
                                <a class="social-media white linkedin" href="#"><i class="fa fa-linkedin-square fa-8x"></i></a>
                                <a class="social-media white pinterest" href="#"><i class="fa fa-pinterest-square fa-8x"></i></a>
                                <a class="social-media white google" href="#"><i class="fa fa-google-plus-square fa-8x"></i></a>
                                <a class="social-media white tumblr" href="#"><i class="fa fa-tumblr-square fa-8x"></i></a>
                                <a class="social-media white instagram" href="#"><i class="fa fa-instagram fa-8x"></i></a>

                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <!-- SOCIAL MEDIA DIVIDER END -->
            <!-- BOTTOM -->
            <div id="foot">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-md-6">
                            <div class="bottom-con">

                                <h5>Visit Us</h5>
                                <hr class="head-border-white" />

                                <div class="">
                                    <p><i class="fa fa-location-arrow"><span><?php echo $config->address?></span></i></p>
                                    </div>

                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="bottom-con">

                                <h5>Write Us</h5>
                                <hr class="head-border-white" />

                                <div class="">
                                    <p><i class="fa fa-phone"><span> <?php echo $config->phone?>,<?php echo $config->phone2?></span></i></p>
                                    <p><i class="fa fa-envelope"><span> <?php echo $config->email?></span></i></p>
                                </div>

                            </div>
                        </div>

                        


                        <div class="col-lg-12 col-md-12 footer">
                            <p class="pull-right"><a href="#about">Back to top</a></p>
                            <p>&copy; 2018-2019 Developed By Muhammad Nadeem Ijaz &middot; </p>
                        </div>

                    </div>
                </div>

            </div>

            <!-- END PRIMARY LAYOUT
        ====================== -->
            <!-- JAVASCRIPT
        ================================================== -->
            <!-- BOOTSTRAP JAVASCRIPT -->
            <script src="<?php echo base_url()?>front/js/jquery-1.10.2.min.js"></script>
            <script type="text/javascript" src="<?php echo base_url()?>front/js/jquery-1.9.1.js"></script>
            <script type="text/javascript" src="<?php echo base_url()?>front/js/bootstrap.min.js"></script>
            <!-- CUSTOM JAVASCRIPT -->
            <!-- Custom Functions -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/functions.js"></script>
            <!-- Portfolio with mixitup filter and prettyphoto -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/jquery.mixitup.min.js"></script>
            <!-- Magnific Popup core JS file -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/magnific.js"></script>
            <!-- BxSlider -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/jquery.bxslider.min.js"></script>
            <!-- Sequence Slider -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/jquery.sequence-min.js"></script>
            <!-- Parallax Background -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/nbw-parallax.js"></script>
            <script type="text/javascript" src="<?php echo base_url()?>front/js/jquery.inview.js"></script>
            <!-- Smooth Scrolling -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/smoothscroll.js"></script>
            <!-- Sticky Navigation -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/jquery.sticky.js"></script>
            <!-- Style Switcher -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/jquery.style-switcher.js"></script>
            <!-- Clients Slider -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/jquery.flexisel.js"></script>
            <!-- Retina JS -->
            <script type="text/javascript" src="<?php echo base_url()?>front/js/retina-1.1.0.min.js"></script>
            
            <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDkQdzhDyGzUEnDMREVFUD8F9Sg2O8uTKc&callback=initMap" async defer></script>

            <script>

                var map;
                var myLatLng = { lat: 30.000435, lng: 73.257925 };
                function initMap() {
                    map = new google.maps.Map(document.getElementById('map'), {
                        center: myLatLng,
                        zoom: 15,
                        scrollwheel: false
                    });
                    var marker = new google.maps.Marker({
                        position: myLatLng,
                        map: map,
                        title: 'Al Abrar Travels & Tours'
                    });
                }

            </script>

        </div>
</body>
</html>

